//
//  main.m
//  ob3_1objects
//
//  Created by Angela on 2020-04-11.
//  Copyright © 2020 angela. All rights reserved.
//


  
#import <Foundation/Foundation.h>
#import "mtime.h"


@implementation mtime

@synthesize year;
//@synthesize month;

- (long) approxsince: (long) whichyear{
    long allsec = 0;
    
    allsec = allsec + /*self.month*/ 6*30*24*60*60;
    allsec = allsec +(self.year- whichyear) *365*30*24*60*60;
    return (allsec);
    
}

- (long) approxsince1970{
    return [self approxsince: 1970];
}

@end

int main(int argc, const char * argv[]) {
    
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    
    mtime *a = [[mtime alloc] init];
    //a.month =6;
    a.year = 2007;
    
    printf ("time since 1970 is about %ld\n", [a approxsince1970]);
    
    return 0;
}
