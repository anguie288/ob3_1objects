//
//  mtime.h
//  ob3_1objects
//
//  Created by Angela on 2020-04-11.
//  Copyright © 2020 angela. All rights reserved.
//

#ifndef mtime_h
#define mtime_h
#endif /* mtime_h */


@interface mtime:NSObject {
    int year;
}

@property (nonatomic) int year;


- (long) approxsince: (long) whichyear;
- (long) approxsince1970;

@end
